package app.musichub

import android.util.Base64
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class Track(val id: String, val title: String, val artist: String, val source: String, val url: String? = null)

private val http = OkHttpClient()

private fun call(req: Request.Builder, headers: Map<String, String>): JSONObject {
    headers.forEach { (k, v) -> req.header(k, v) }
    http.newCall(req.build()).execute().use {
        val json = JSONObject(it.body!!.string())
        json.optJSONObject("error")?.let { e -> error(e.optString("error_msg", e.optString("message", "ошибка API"))) }
        return json
    }
}

/** Неофициальный API Яндекс Музыки (как в библиотеке yandex-music). */
class Yandex(token: String) {
    private val base = "https://api.music.yandex.net"
    private val signKey = "kzqU4XhfCaY6B6JTHODeq5" // может измениться — см. библиотеку yandex-music
    private val h = mapOf("Authorization" to "OAuth $token", "X-Yandex-Music-Client" to "YandexMusicAndroid/24023621")

    fun liked(): List<Track> {
        val uid = call(Request.Builder().url("$base/account/status"), h)
            .getJSONObject("result").getJSONObject("account").optString("uid")
        val lib = call(Request.Builder().url("$base/users/$uid/likes/tracks"), h)
            .getJSONObject("result").getJSONObject("library").getJSONArray("tracks")
        val ids = (0 until minOf(lib.length(), 100)).joinToString(",") { lib.getJSONObject(it).optString("id") }
        val body = FormBody.Builder().add("track-ids", ids).build()
        val arr = call(Request.Builder().url("$base/tracks").post(body), h).getJSONArray("result")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val a = o.optJSONArray("artists")
            val names = (0 until (a?.length() ?: 0)).joinToString(", ") { i -> a!!.getJSONObject(i).optString("name") }
            Track(o.optString("id"), o.optString("title"), names, "Яндекс")
        }
    }

    /** Ссылка на mp3 живёт недолго, поэтому запрашиваем её прямо перед воспроизведением. */
    fun streamUrl(id: String): String {
        val ts = System.currentTimeMillis() / 1000
        val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(signKey.toByteArray(), "HmacSHA256")) }
        val raw = Base64.encodeToString(mac.doFinal("$ts${id}nqmp3raw".toByteArray()), Base64.NO_WRAP)
        val sign = URLEncoder.encode(raw.dropLast(1), "UTF-8")
        val url = "$base/get-file-info?ts=$ts&trackId=$id&quality=nq&codecs=mp3&transports=raw&sign=$sign"
        return call(Request.Builder().url(url), h).getJSONObject("result").getJSONObject("downloadInfo").getString("url")
    }
}

/** Неофициальный доступ к VK Музыке через токен Kate Mobile. VK может блокировать такие запросы. */
class Vk(private val token: String) {
    private val h = mapOf("User-Agent" to "KateMobileAndroid/56 lite-460 (Android 4.4.2; SDK 19; x86; unknown Android SDK built for x86; en)")

    fun audio(): List<Track> {
        val r = call(Request.Builder().url("https://api.vk.com/method/audio.get?access_token=$token&v=5.131&count=100"), h)
        val items = r.getJSONObject("response").getJSONArray("items")
        return (0 until items.length()).map {
            val o = items.getJSONObject(it)
            Track("vk${o.optInt("owner_id")}_${o.optInt("id")}", o.optString("title"), o.optString("artist"), "VK", o.optString("url").ifEmpty { null })
        }
    }
}
