package app.musichub

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val YA_AUTH = "https://oauth.yandex.ru/authorize?response_type=token&client_id=23cabbbdc6cd418abb4b39c32c41195d"
private const val VK_AUTH = "https://oauth.vk.com/authorize?client_id=2685278&scope=audio,offline&redirect_uri=https://oauth.vk.com/blank.html&display=mobile&response_type=token&v=5.131"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginWebView(url: String, onToken: (String) -> Unit) {
    AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
        WebView(c).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                private fun check(u: String?) { Regex("access_token=([^&]+)").find(u ?: "")?.let { onToken(it.groupValues[1]) } }
                override fun onPageStarted(v: WebView, u: String?, f: android.graphics.Bitmap?) = check(u)
                override fun doUpdateVisitedHistory(v: WebView, u: String?, r: Boolean) = check(u)
            }
            loadUrl(url)
        }
    })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("tokens", 0) }
    val scope = rememberCoroutineScope()
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var ya by remember { mutableStateOf(prefs.getString("ya", null)) }
    var vk by remember { mutableStateOf(prefs.getString("vk", null)) }
    var tracks by remember { mutableStateOf(listOf<Track>()) }
    var status by remember { mutableStateOf("") }
    var login by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf("Все") }
    var current by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }

    DisposableEffect(player) {
        val l = object : Player.Listener { override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying } }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    LaunchedEffect(ya, vk) {
        status = if (ya != null || vk != null) "Загрузка…" else "Войдите хотя бы в один сервис"
        val (list, errs) = withContext(Dispatchers.IO) {
            val out = mutableListOf<Track>(); val errs = mutableListOf<String>()
            ya?.let { runCatching { out += Yandex(it).liked() }.onFailure { e -> errs += "Яндекс: ${e.message}" } }
            vk?.let { runCatching { out += Vk(it).audio() }.onFailure { e -> errs += "VK: ${e.message}" } }
            out.toList() to errs.toList()
        }
        tracks = list
        status = errs.joinToString("\n")
    }

    fun setToken(src: String, t: String?) {
        prefs.edit().putString(src, t).apply()
        if (src == "ya") ya = t else vk = t
    }

    fun play(t: Track) {
        current = t
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    t.url ?: if (t.source == "Яндекс") Yandex(ya!!).streamUrl(t.id) else error("трек недоступен")
                }
            }.onSuccess {
                player.setMediaItem(MediaItem.fromUri(it)); player.prepare(); player.play()
            }.onFailure { status = "Не удалось воспроизвести: ${it.message}" }
        }
    }

    BackHandler(login != null) { login = null }
    val src = login
    if (src != null) {
        LoginWebView(if (src == "ya") YA_AUTH else VK_AUTH) { setToken(src, it); login = null }
    } else {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ if (ya == null) login = "ya" else setToken("ya", null) }) { Text(if (ya == null) "Войти: Яндекс" else "Яндекс ✓ выйти") }
                OutlinedButton({ if (vk == null) login = "vk" else setToken("vk", null) }) { Text(if (vk == null) "Войти: VK" else "VK ✓ выйти") }
            }
            Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Все", "Яндекс", "VK").forEach { FilterChip(filter == it, { filter = it }, { Text(it) }) }
            }
            if (status.isNotEmpty()) Text(status, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
            LazyColumn(Modifier.weight(1f)) {
                items(tracks.filter { filter == "Все" || it.source == filter }) { t ->
                    ListItem(
                        headlineContent = { Text(t.title, maxLines = 1) },
                        supportingContent = { Text("${t.artist} · ${t.source}", maxLines = 1) },
                        modifier = Modifier.clickable { play(t) }
                    )
                }
            }
            current?.let { t ->
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${t.artist} — ${t.title}", Modifier.weight(1f), maxLines = 1)
                    TextButton({ if (playing) player.pause() else player.play() }) { Text(if (playing) "⏸" else "▶") }
                }
            }
        }
    }
}
